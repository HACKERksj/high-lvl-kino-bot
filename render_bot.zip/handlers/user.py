from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes, CommandHandler, MessageHandler,
    CallbackQueryHandler, filters
)
from telegram.constants import ChatAction
import db
from config import AD_MESSAGE, ADMIN_ID
from services.movie_service import send_movie, search_movies, get_random

# =============================================
# 🎮 USER HANDLERS — handlers/user.py
# =============================================

def _main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🎬 Random Kino", callback_data="random"),
            InlineKeyboardButton("🔍 Qidirish",    callback_data="search"),
        ],
        [
            InlineKeyboardButton("📊 Statistikam", callback_data="mystats"),
            InlineKeyboardButton("ℹ️ Yordam",       callback_data="help"),
        ],
        [
            InlineKeyboardButton("💎 Premium",       callback_data="premium"),
            InlineKeyboardButton("👥 Do'st taklif",  callback_data="referral"),
        ],
    ])


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    # Referral tekshirish: /start ref_12345
    referred_by = None
    if context.args:
        arg = context.args[0]
        if arg.startswith("ref_"):
            try:
                referred_by = int(arg.split("_")[1])
                if referred_by == user.id:
                    referred_by = None
            except (IndexError, ValueError):
                pass

    is_new = db.get_or_create_user(
        user.id,
        user.username or "",
        user.full_name or "",
        referred_by=referred_by
    )

    welcome = (
        f"👋 Salom, <b>{user.first_name}</b>!\n\n"
        f"🎬 <b>Movie Code Bot</b> ga xush kelibsiz!\n\n"
        f"📌 Kino kodini yuboring va filmni oling.\n"
        f"Masalan: <code>001</code> yoki <code>847</code>\n\n"
        f"{'🎉 Birinchi marta keldingiz, xush kelibsiz!' if is_new else '🔄 Yana keldingiz!'}"
    )

    await update.message.reply_text(
        welcome,
        parse_mode="HTML",
        reply_markup=_main_menu()
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "ℹ️ <b>YORDAM</b>\n\n"
        "🎬 <b>Kino olish:</b> Shunchaki kino kodini yuboring\n"
        "   Masalan: <code>001</code>\n\n"
        "🔍 <b>Qidirish:</b> /search John Wick\n\n"
        "📊 <b>Statistika:</b> /mystats\n\n"
        "💎 <b>Premium:</b> /premium\n\n"
        "👥 <b>Referral:</b> /referral — do'stlarni taklif qiling\n\n"
        "🎲 <b>Random kino:</b> /random"
    )
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=_main_menu())


async def cmd_mystats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user = db.get_user(user_id)
    if not user:
        await update.message.reply_text("❌ Siz hali ro'yxatdan o'tmagansiz.")
        return

    premium_badge = "💎 Premium" if user["is_premium"] else "🆓 Free"
    await update.message.reply_text(
        f"📊 <b>SIZNING STATISTIKANGIZ</b>\n\n"
        f"👤 ID: <code>{user_id}</code>\n"
        f"🏷 Tur: {premium_badge}\n"
        f"👥 Taklif qilganlar: {user['referral_count']}\n"
        f"📅 Qo'shilgan: {user['joined_at'][:10]}\n"
        f"🕐 Oxirgi faollik: {user['last_active'][:10]}",
        parse_mode="HTML"
    )


async def cmd_referral(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    bot_username = (await context.bot.get_me()).username
    link = f"https://t.me/{bot_username}?start=ref_{user_id}"
    user = db.get_user(user_id)
    ref_count = user["referral_count"] if user else 0

    await update.message.reply_text(
        f"👥 <b>DO'ST TAKLIF QILING</b>\n\n"
        f"Havolangiz:\n{link}\n\n"
        f"✅ Har 5 ta taklif uchun Premium olasiz!\n"
        f"📌 Sizning taklif soningiz: {ref_count}",
        parse_mode="HTML"
    )


async def cmd_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(
            "🔍 Format: /search <KINO NOMI>\nMisol: /search John Wick"
        )
        return
    query = " ".join(context.args)
    await _do_search(update, context, query)


async def _do_search(update: Update, context: ContextTypes.DEFAULT_TYPE, query: str):
    results = search_movies(query)
    if not results:
        await update.message.reply_text(
            f"😔 <b>'{query}'</b> bo'yicha hech narsa topilmadi.",
            parse_mode="HTML"
        )
        return

    buttons = []
    for m in results:
        badge = "💎" if m["is_premium"] else "🎬"
        buttons.append([
            InlineKeyboardButton(
                f"{badge} {m['name']} [{m['code']}]",
                callback_data=f"get_{m['code']}"
            )
        ])
    buttons.append([InlineKeyboardButton("❌ Yopish", callback_data="close")])

    await update.message.reply_text(
        f"🔍 <b>'{query}'</b> bo'yicha natijalar:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def cmd_random(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.send_chat_action(update.effective_chat.id, ChatAction.TYPING)
    movie = get_random()
    if not movie:
        await update.message.reply_text("😔 Hozircha kinolar yo'q.")
        return

    user = db.get_user(update.effective_user.id)
    is_premium = user["is_premium"] if user else False
    result = await send_movie(context.bot, update.effective_chat.id, movie["code"], is_premium)
    await _handle_movie_result(update, result, movie["name"])


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Matn xabar: kod yoki qidirish."""
    text = update.message.text.strip()
    await context.bot.send_chat_action(update.effective_chat.id, ChatAction.TYPING)

    # User DB da yo'q bo'lsa yaratish
    user_data = db.get_user(update.effective_user.id)
    if not user_data:
        db.get_or_create_user(
            update.effective_user.id,
            update.effective_user.username or "",
            update.effective_user.full_name or ""
        )
        user_data = {"is_premium": False}

    is_premium = bool(user_data.get("is_premium", False))

    # Kod formatini tekshirish (faqat raqam yoki harf+raqam, max 10 belgi)
    cleaned = text.replace(" ", "")
    if cleaned.isalnum() and len(cleaned) <= 10:
        result = await send_movie(context.bot, update.effective_chat.id, cleaned, is_premium)
        await _handle_movie_result(update, result, cleaned)
    else:
        # Matn bo'lsa — qidirish
        await _do_search(update, context, text)


async def _handle_movie_result(update: Update, result: str, identifier: str):
    if result == "ok":
        if AD_MESSAGE:
            await update.message.reply_text(AD_MESSAGE)
    elif result == "not_found":
        await update.message.reply_text(
            f"😔 <b>'{identifier}'</b> kodi topilmadi.\n\n"
            f"🔍 Kino nomini yozib qidiring.",
            parse_mode="HTML"
        )
    elif result == "premium_required":
        await update.message.reply_text(
            "💎 <b>Bu kino faqat Premium foydalanuvchilar uchun!</b>\n\n"
            "Premium olish uchun: /premium\n"
            "Yoki do'stlarni taklif qiling: /referral",
            parse_mode="HTML"
        )
    elif result == "error":
        await update.message.reply_text(
            "❌ Xatolik yuz berdi. Iltimos, qayta urinib ko'ring."
        )


async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Inline button callback larni boshqaradi."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "random":
        await context.bot.send_chat_action(query.message.chat.id, ChatAction.TYPING)
        movie = get_random()
        if not movie:
            await query.message.reply_text("😔 Hozircha kinolar yo'q.")
            return
        user = db.get_user(query.from_user.id)
        is_premium = bool(user["is_premium"]) if user else False
        result = await send_movie(context.bot, query.message.chat.id, movie["code"], is_premium)
        if result != "ok":
            await _handle_movie_result(query.message, result, movie["name"])

    elif data == "search":
        await query.message.reply_text(
            "🔍 Kino nomini yuboring (masalan: <code>John Wick</code>)",
            parse_mode="HTML"
        )

    elif data == "mystats":
        user_id = query.from_user.id
        user = db.get_user(user_id)
        if user:
            badge = "💎 Premium" if user["is_premium"] else "🆓 Free"
            await query.message.reply_text(
                f"📊 Sizning statistikangiz:\n"
                f"👤 ID: <code>{user_id}</code>\n"
                f"🏷 Tur: {badge}\n"
                f"👥 Taklif: {user['referral_count']}\n"
                f"📅 A'zo bo'lgan: {user['joined_at'][:10]}",
                parse_mode="HTML"
            )

    elif data == "help":
        await cmd_help(update, context)

    elif data == "premium":
        await query.message.reply_text(
            "💎 <b>PREMIUM</b>\n\n"
            "Premium olish usullari:\n"
            "1️⃣ 5 ta do'stni taklif qiling → /referral\n"
            "2️⃣ Admin bilan bog'laning",
            parse_mode="HTML"
        )

    elif data == "referral":
        bot_username = (await context.bot.get_me()).username
        user_id = query.from_user.id
        link = f"https://t.me/{bot_username}?start=ref_{user_id}"
        user = db.get_user(user_id)
        ref_count = user["referral_count"] if user else 0
        await query.message.reply_text(
            f"👥 Sizning havolangiz:\n{link}\n\n"
            f"📌 Taklif soningiz: {ref_count}\n"
            f"Har 5 ta taklif = 1 ta Premium! 💎",
        )

    elif data.startswith("get_"):
        code = data[4:]
        user = db.get_user(query.from_user.id)
        is_premium = bool(user["is_premium"]) if user else False
        await context.bot.send_chat_action(query.message.chat.id, ChatAction.TYPING)
        result = await send_movie(context.bot, query.message.chat.id, code, is_premium)
        if result != "ok":
            await _handle_movie_result(query.message, result, code)

    elif data == "close":
        await query.message.delete()


def get_user_handlers():
    return [
        CommandHandler("start",    cmd_start),
        CommandHandler("help",     cmd_help),
        CommandHandler("mystats",  cmd_mystats),
        CommandHandler("referral", cmd_referral),
        CommandHandler("search",   cmd_search),
        CommandHandler("random",   cmd_random),
        CallbackQueryHandler(handle_callback),
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text),
    ]
