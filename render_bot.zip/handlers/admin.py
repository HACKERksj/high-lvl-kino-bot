from telegram import Update
from telegram.ext import ContextTypes, CommandHandler
from telegram.helpers import escape_markdown
from html import escape
from config import ADMIN_ID
import db
from services.movie_service import add_movie_to_db, delete_movie_from_db, edit_movie_in_db
from services.cache_service import cache_size

# =============================================
# 🔐 ADMIN HANDLERS — handlers/admin.py
# =============================================

def admin_only(func):
    """Decorator: faqat admin ishlata oladi."""
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if user_id != int(ADMIN_ID):
            await update.message.reply_text(
                f"⛔ Siz admin emassiz.\n"
                f"Sizning ID: <code>{user_id}</code>",
                parse_mode="HTML"
            )
            return
        return await func(update, context)
    return wrapper


@admin_only
async def cmd_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /add CODE NAME MESSAGE_ID
    /add 001 John Wick 12345
    Premium: /add P001 John Wick 12345
    """
    args = context.args
    if len(args) < 3:
        await update.message.reply_text(
            "❌ Format: /add KOD NOMI MESSAGE_ID\n\n"
            "Misol: <code>/add 001 John Wick 12345</code>\n"
            "Premium: <code>/add P001 John Wick 12345</code>",
            parse_mode="HTML"
        )
        return

    code = args[0]
    name = " ".join(args[1:-1])
    try:
        message_id = int(args[-1])
    except ValueError:
        await update.message.reply_text("❌ MESSAGE_ID raqam bo'lishi kerak.")
        return

    is_premium = code.upper().startswith("P")
    success = await add_movie_to_db(code, name, message_id, is_premium)

    if success:
        badge = "💎 Premium" if is_premium else "🆓 Free"
        await update.message.reply_text(
            f"✅ Kino qo'shildi!\n\n"
            f"🎬 Nomi: <b>{escape(name)}</b>\n"
            f"🔑 Kod: <code>{escape(code.upper())}</code>\n"
            f"📌 Message ID: <code>{message_id}</code>\n"
            f"🏷 Tur: {badge}",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            f"❌ <code>{escape(code.upper())}</code> kodi allaqachon mavjud!",
            parse_mode="HTML"
        )


@admin_only
async def cmd_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/delete CODE"""
    if not context.args:
        await update.message.reply_text(
            "❌ Format: /delete <KOD>\nMisol: <code>/delete 001</code>",
            parse_mode="HTML"
        )
        return

    code = context.args[0]
    success = delete_movie_from_db(code)

    if success:
        await update.message.reply_text(f"🗑 <code>{code.upper()}</code> o'chirildi.", parse_mode="HTML")
    else:
        await update.message.reply_text(f"❌ <code>{code.upper()}</code> topilmadi.", parse_mode="HTML")


@admin_only
async def cmd_edit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/edit CODE NEW NAME"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "❌ Format: /edit <KOD> <YANGI NOMI>\n"
            "Misol: <code>/edit 001 John Wick 2</code>",
            parse_mode="HTML"
        )
        return

    code = context.args[0]
    new_name = " ".join(context.args[1:])
    success = edit_movie_in_db(code, new_name)

    if success:
        await update.message.reply_text(
            f"✏️ Yangilandi!\n🔑 Kod: <code>{escape(code.upper())}</code>\n🎬 Yangi nomi: <b>{escape(new_name)}</b>",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(f"❌ <code>{escape(code.upper())}</code> topilmadi.", parse_mode="HTML")


@admin_only
async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/stats — statistika"""
    stats = db.get_stats()
    await update.message.reply_text(
        f"📊 <b>BOT STATISTIKASI</b>\n\n"
        f"👥 Jami foydalanuvchilar: <b>{stats['total_users']}</b>\n"
        f"📥 Jami so'rovlar: <b>{stats['total_requests']}</b>\n"
        f"🔥 Eng ko'p ko'rilgan: <b>{stats['top_movie']}</b>\n"
        f"📅 Bugungi so'rovlar: <b>{stats['daily_requests']}</b>\n"
        f"⚡ Cache da kinolar: <b>{cache_size()}</b>",
        parse_mode="HTML"
    )


@admin_only
async def cmd_premium(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/setpremium USER_ID"""
    if not context.args:
        await update.message.reply_text("❌ Format: /setpremium <USER_ID>")
        return
    try:
        uid = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ USER_ID raqam bo'lishi kerak.")
        return

    db.set_premium(uid, True)
    await update.message.reply_text(f"💎 <code>{uid}</code> ga premium berildi!", parse_mode="HTML")


@admin_only
async def cmd_myid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/myid — admin ID ni ko'rsatish"""
    await update.message.reply_text(
        f"✅ Siz adminsiz!\n👤 ID: <code>{update.effective_user.id}</code>",
        parse_mode="HTML"
    )


def get_admin_handlers():
    return [
        CommandHandler("add",        cmd_add),
        CommandHandler("delete",     cmd_delete),
        CommandHandler("edit",       cmd_edit),
        CommandHandler("stats",      cmd_stats),
        CommandHandler("setpremium", cmd_premium),
        CommandHandler("myid",       cmd_myid),
    ]