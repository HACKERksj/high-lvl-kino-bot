import re
from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters
from config import CHANNEL_ID
from services.movie_service import add_movie_to_db

# =============================================
# 📡 CHANNEL HANDLER — handlers/channel.py
# =============================================
#
# Channel post formati:
#   🎬 John Wick
#   #001
#
# Bot channel postini detect qilib, avtomatik DB ga qo'shadi.
# =============================================

CODE_PATTERN = re.compile(r"#([A-Za-z0-9]+)")
NAME_PATTERN = re.compile(r"🎬\s*(.+)")


async def handle_channel_post(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Channeldan yangi post kelganda avtomatik kino qo'shadi."""
    post = update.channel_post
    if not post or not post.text:
        return

    # Faqat bizning channeldan
    chat_id = post.chat.id
    chat_username = post.chat.username or ""
    target = str(CHANNEL_ID).lstrip("@").lstrip("-100")

    if str(chat_id) not in [f"-100{target}", target] and chat_username != target:
        return

    text = post.text
    code_match = CODE_PATTERN.search(text)
    name_match = NAME_PATTERN.search(text)

    if not code_match or not name_match:
        return  # Format mos kelmadi

    code = code_match.group(1)
    name = name_match.group(1).strip()
    message_id = post.message_id
    is_premium = code.upper().startswith("P")

    success = await add_movie_to_db(code, name, message_id, is_premium)
    if success:
        print(f"📥 Yangi kino qo'shildi channel orqali: [{code}] {name} (msg_id={message_id})")
    else:
        print(f"⚠️ Channel post: [{code}] allaqachon mavjud.")


def get_channel_handlers():
    return [
        MessageHandler(filters.UpdateType.CHANNEL_POSTS, handle_channel_post),
    ]
