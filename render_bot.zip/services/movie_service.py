from telegram import Bot
from telegram.error import TelegramError, BadRequest, Forbidden, ChatMigrated
from config import CHANNEL_ID
import db
from services.cache_service import (
    get_from_cache, set_in_cache, delete_from_cache, update_cache_entry
)

# =============================================
# 🎬 MOVIE SERVICE — services/movie_service.py
# =============================================

# CHANNEL_ID ni har doim int ga o'girish
def _channel_id():
    try:
        return int(CHANNEL_ID)
    except (ValueError, TypeError):
        # "@username" formatida bo'lsa string qoladi
        return str(CHANNEL_ID)


async def send_movie(bot: Bot, chat_id: int, code: str, user_is_premium: bool) -> str:
    """
    Kinoni userga yuboradi.
    Returns: "ok" | "not_found" | "premium_required" | "error"
    """
    # 1. Cache dan qidirish
    cached = get_from_cache(code)

    if not cached:
        # 2. DB dan qidirish
        movie = db.get_movie_by_code(code)
        if not movie:
            return "not_found"
        set_in_cache(movie["code"], movie["name"], movie["message_id"], bool(movie["is_premium"]))
        cached = get_from_cache(code)

    # Premium tekshirish
    if cached["is_premium"] and not user_is_premium:
        return "premium_required"

    channel = _channel_id()
    message_id = int(cached["message_id"])

    print(f"📤 copy_message: from_chat_id={channel} ({type(channel).__name__}), message_id={message_id}, to={chat_id}")

    try:
        await bot.copy_message(
            chat_id=chat_id,
            from_chat_id=channel,
            message_id=message_id,
        )
        db.log_request(chat_id, code.upper())
        return "ok"

    except Forbidden as e:
        print(f"❌ Forbidden: Bot kanalga kirish huquqi yo'q! {e}")
        return "error"
    except BadRequest as e:
        print(f"❌ BadRequest: Message topilmadi yoki noto'g'ri ID. {e}")
        return "error"
    except ChatMigrated as e:
        print(f"❌ ChatMigrated: Kanal ID o'zgardi: {e.new_chat_id}")
        return "error"
    except TelegramError as e:
        print(f"❌ TelegramError: {type(e).__name__}: {e}")
        return "error"
    except Exception as e:
        print(f"❌ Unexpected error: {type(e).__name__}: {e}")
        return "error"


async def add_movie_to_db(code: str, name: str, message_id: int, is_premium: bool = False) -> bool:
    success = db.add_movie(code, name, message_id, is_premium)
    if success:
        set_in_cache(code, name, message_id, is_premium)
    return success


def delete_movie_from_db(code: str) -> bool:
    success = db.delete_movie(code)
    if success:
        delete_from_cache(code)
    return success


def edit_movie_in_db(code: str, new_name: str) -> bool:
    success = db.edit_movie_name(code, new_name)
    if success:
        update_cache_entry(code, new_name)
    return success


def search_movies(query: str) -> list:
    return db.search_movies_by_name(query, limit=5)


def get_random() -> dict | None:
    return db.get_random_movie()
