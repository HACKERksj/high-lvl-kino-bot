import time
from db import get_all_movies

# =============================================
# ⚡ CACHE SERVICE — services/cache_service.py
# =============================================

# RAM cache: { "CODE": {"name": ..., "message_id": ..., "is_premium": ..., "ts": ...} }
_cache: dict = {}
_last_full_load: float = 0.0


def load_all_to_cache():
    """DB dagi barcha kinolarni RAM ga yuklaydi."""
    global _last_full_load
    movies = get_all_movies()
    for m in movies:
        _cache[m["code"]] = {
            "name": m["name"],
            "message_id": m["message_id"],
            "is_premium": bool(m["is_premium"]),
            "ts": time.time(),
        }
    _last_full_load = time.time()
    print(f"✅ Cache loaded: {len(_cache)} movies.")


def get_from_cache(code: str) -> dict | None:
    return _cache.get(code.upper())


def set_in_cache(code: str, name: str, message_id: int, is_premium: bool = False):
    _cache[code.upper()] = {
        "name": name,
        "message_id": message_id,
        "is_premium": is_premium,
        "ts": time.time(),
    }


def delete_from_cache(code: str):
    _cache.pop(code.upper(), None)


def update_cache_entry(code: str, name: str):
    if code.upper() in _cache:
        _cache[code.upper()]["name"] = name


def cache_size() -> int:
    return len(_cache)
